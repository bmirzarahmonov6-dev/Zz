package uz.zikr.app

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import kotlin.math.max

class StatsActivity : Activity() {

    private var days = 7

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        build()
    }

    override fun onResume() {
        super.onResume()
        build()
    }

    private fun build() {
        val (sv, root) = Ui.page(this)
        root.addView(Ui.text(this, "Statistika", 26f, Ui.TEXT, true))

        val (values, labels) = ZikrPrefs.lastDays(this, days)
        val goal = if (ZikrPrefs.totalMode(this)) 0 else ZikrPrefs.goal(this)
        val avg = if (values.isEmpty()) 0 else values.sum() / values.size

        val r1 = Ui.row(this)
        r1.addView(statCard("Bugun", ZikrPrefs.today(this).toString()), cardLp())
        r1.addView(statCard("Jami", ZikrPrefs.total(this).toString()), cardLp())
        root.addView(r1, Ui.wrapLp(this, 20))

        val r2 = Ui.row(this)
        r2.addView(statCard("Ketma-ket maqsad kunlari", ZikrPrefs.streak(this).toString()), cardLp())
        r2.addView(statCard("O'rtacha (kuniga, $days kun)", avg.toString()), cardLp())
        root.addView(r2, Ui.wrapLp(this, 10))

        val toggle = Ui.row(this)
        toggle.addView(Ui.button(this, "7 kun", if (days == 7) Ui.ACCENT else Ui.CARD) { days = 7; build() }, Ui.weightLp(this, 44, 3))
        toggle.addView(Ui.button(this, "30 kun", if (days == 30) Ui.ACCENT else Ui.CARD) { days = 30; build() }, Ui.weightLp(this, 44, 3))
        root.addView(toggle, Ui.wrapLp(this, 20))

        root.addView(Ui.text(this, "Oxirgi $days kun", 14f, Ui.MUTED), Ui.wrapLp(this, 16))
        root.addView(BarChartView(this, values, labels, goal), Ui.wrapLp(this, 8))

        root.addView(Ui.button(this, "Orqaga", Ui.NEUTRAL) { finish() }, Ui.lp(this, 48, 24))
        setContentView(sv)
    }

    private fun cardLp() = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
        marginStart = Ui.dp(this@StatsActivity, 4)
        marginEnd = Ui.dp(this@StatsActivity, 4)
    }

    private fun statCard(label: String, value: String): LinearLayout {
        val box = Ui.card(this)
        box.addView(Ui.text(this, value, 28f, Ui.ACCENT_LIGHT, true))
        box.addView(Ui.text(this, label, 12f, Ui.MUTED))
        return box
    }
}

class BarChartView(
    c: Context,
    private val values: IntArray,
    private val labels: Array<String>,
    private val goal: Int
) : View(c) {

    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Ui.MUTED
        textAlign = Paint.Align.CENTER
        textSize = Ui.dp(c, 11).toFloat()
    }
    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Ui.TEXT
        textAlign = Paint.Align.CENTER
        textSize = Ui.dp(c, 11).toFloat()
    }
    private val goalPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFBBF24.toInt()
        style = Paint.Style.STROKE
        strokeWidth = Ui.dp(c, 1).toFloat()
        pathEffect = DashPathEffect(floatArrayOf(10f, 8f), 0f)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), Ui.dp(context, 220))
    }

    override fun onDraw(canvas: Canvas) {
        val n = values.size
        if (n == 0) return
        val top = Ui.dp(context, 20).toFloat()
        val bottom = height - Ui.dp(context, 24).toFloat()
        val chartH = bottom - top
        val maxV = max(max(values.maxOrNull() ?: 0, goal), 1).toFloat()
        val slot = width.toFloat() / n
        val barW = slot * 0.6f

        for (i in 0 until n) {
            val h = values[i] / maxV * chartH
            val left = i * slot + (slot - barW) / 2f
            barPaint.color = if (values[i] >= goal) Ui.ACCENT_LIGHT else 0xFF475569.toInt()
            canvas.drawRoundRect(RectF(left, bottom - h, left + barW, bottom), 6f, 6f, barPaint)
            val show = n <= 10 || i % 5 == 0 || i == n - 1
            if (show) canvas.drawText(labels[i], i * slot + slot / 2f, height - 6f, labelPaint)
            if (n <= 7 && values[i] > 0) {
                canvas.drawText(values[i].toString(), i * slot + slot / 2f, bottom - h - 6f, valuePaint)
            }
        }
        if (goal > 0) {
            val gy = bottom - goal / maxV * chartH
            canvas.drawLine(0f, gy, width.toFloat(), gy, goalPaint)
        }
    }
}
