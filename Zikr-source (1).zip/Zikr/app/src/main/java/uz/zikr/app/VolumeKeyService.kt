package uz.zikr.app

import android.accessibilityservice.AccessibilityService
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * Ovoz tugmalarini ushlaydi: yuqori = +1, past = -1.
 * Ekran o'chiq bo'lganda ham ishlaydi.
 */
class VolumeKeyService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        if (!ZikrPrefs.volumeKeys(this)) return false
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            ZikrPrefs.add(this, if (code == KeyEvent.KEYCODE_VOLUME_UP) 1 else -1)
        }
        return true
    }
}
