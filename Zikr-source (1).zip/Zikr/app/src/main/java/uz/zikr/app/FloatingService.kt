package uz.zikr.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.VolumeProvider
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.min

class FloatingService : Service() {

    companion object {
        const val ACTION_STOP = "uz.zikr.app.STOP"
        const val CHANNEL_ID = "zikr_channel"
        const val NOTIF_ID = 1
    }

    private lateinit var wm: WindowManager
    private var view: CounterView? = null
    private lateinit var lp: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())

    private var session: MediaSession? = null
    @Volatile private var silentPlaying = false

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_SCREEN_OFF -> startVolumeCapture()
                Intent.ACTION_SCREEN_ON -> stopVolumeCapture()
            }
        }
    }

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        handler.post { onPrefChanged(key) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createChannel()
        ZikrPrefs.sp(this).registerOnSharedPreferenceChangeListener(prefsListener)
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(screenReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(screenReceiver, f)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            ZikrPrefs.setRunning(this, false)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (view == null) {
            if (!Settings.canDrawOverlays(this)) {
                ZikrPrefs.setRunning(this, false)
                stopSelf()
                return START_NOT_STICKY
            }
            addOverlay()
        }
        ZikrPrefs.setRunning(this, true)
        return START_STICKY
    }

    override fun onDestroy() {
        ZikrPrefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefsListener)
        handler.removeCallbacksAndMessages(null)
        runCatching { unregisterReceiver(screenReceiver) }
        stopVolumeCapture()
        view?.let { runCatching { wm.removeView(it) } }
        view = null
        ZikrPrefs.setRunning(this, false)
        super.onDestroy()
    }

    private fun px(dp: Int): Int = (dp * resources.displayMetrics.density).toInt()

    private fun addOverlay() {
        val size = px(ZikrPrefs.sizeDp(this))
        val dm = resources.displayMetrics
        lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            val sx = ZikrPrefs.sp(this@FloatingService).getInt(ZikrPrefs.KEY_X, -1)
            val sy = ZikrPrefs.sp(this@FloatingService).getInt(ZikrPrefs.KEY_Y, -1)
            x = if (sx >= 0) sx else dm.widthPixels - size - px(12)
            y = if (sy >= 0) sy else dm.heightPixels / 3
        }
        clamp()
        val v = CounterView()
        view = v
        wm.addView(v, lp)
    }

    private fun clamp() {
        val dm = resources.displayMetrics
        lp.x = lp.x.coerceIn(0, (dm.widthPixels - lp.width).coerceAtLeast(0))
        lp.y = lp.y.coerceIn(0, (dm.heightPixels - lp.height).coerceAtLeast(0))
    }

    private fun onPrefChanged(key: String?) {
        val v = view ?: return
        if (key == ZikrPrefs.KEY_SIZE) {
            val s = px(ZikrPrefs.sizeDp(this))
            lp.width = s
            lp.height = s
            clamp()
            runCatching { wm.updateViewLayout(v, lp) }
        }
        v.invalidate()
        if (key == null || key.startsWith("d_") || key == ZikrPrefs.KEY_GOAL || key == ZikrPrefs.KEY_GOAL_MODE) updateNotification()
    }

    /** Doira: bitta oddiy yashil yumaloq va ichida son. Bosish = +1. Sudrash = ko'chirish. */
    private inner class CounterView : View(this@FloatingService) {
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        private val slop = ViewConfiguration.get(this@FloatingService).scaledTouchSlop
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        private var moved = false

        override fun onDraw(canvas: Canvas) {
            val ctx = this@FloatingService
            val r = min(width, height) / 2f
            bg.color = ZikrPrefs.palettes[ZikrPrefs.colorIdx(ctx)].color
            bg.alpha = ZikrPrefs.alphaPct(ctx) * 255 / 100
            canvas.drawCircle(width / 2f, height / 2f, r, bg)
            val s = ZikrPrefs.progress(ctx).toString()
            val factor = when (s.length) {
                1, 2, 3 -> 0.42f
                4 -> 0.34f
                5 -> 0.30f
                6 -> 0.26f
                else -> 0.22f
            }
            tp.textSize = width * factor
            val y = height / 2f - (tp.descent() + tp.ascent()) / 2f
            canvas.drawText(s, width / 2f, y, tp)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && (abs(dx) > slop || abs(dy) > slop)) moved = true
                    if (moved) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        clamp()
                        runCatching { wm.updateViewLayout(this, lp) }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        ZikrPrefs.sp(this@FloatingService).edit()
                            .putInt(ZikrPrefs.KEY_X, lp.x)
                            .putInt(ZikrPrefs.KEY_Y, lp.y)
                            .apply()
                    } else {
                        ZikrPrefs.add(this@FloatingService, 1)
                    }
                }
            }
            return true
        }
    }

    /**
     * Ekran o'chiq paytda ovoz tugmasini ushlash:
     * jim audio "musiqa chalayapti" deb ko'rsatadi, media sessiya esa tugmani oladi.
     */
    private fun startVolumeCapture() {
        if (!ZikrPrefs.volumeKeys(this) || session != null) return
        val s = MediaSession(this, "ZikrVolume")
        val provider = object : VolumeProvider(VOLUME_CONTROL_RELATIVE, 100, 50) {
            override fun onAdjustVolume(direction: Int) {
                if (direction > 0) ZikrPrefs.add(this@FloatingService, 1)
                else if (direction < 0) ZikrPrefs.add(this@FloatingService, -1)
            }
        }
        s.setPlaybackToRemote(provider)
        s.setPlaybackState(
            PlaybackState.Builder()
                .setState(PlaybackState.STATE_PLAYING, 0L, 1f)
                .setActions(0L)
                .build()
        )
        s.isActive = true
        session = s
        startSilentAudio()
    }

    private fun stopVolumeCapture() {
        silentPlaying = false
        session?.let {
            runCatching { it.isActive = false }
            runCatching { it.release() }
        }
        session = null
    }

    private fun startSilentAudio() {
        if (silentPlaying) return
        silentPlaying = true
        Thread {
            val rate = 8000
            val minBuf = AudioTrack.getMinBufferSize(
                rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(minBuf.coerceAtLeast(4096))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track.play()
            val silence = ShortArray(2048)
            while (silentPlaying) track.write(silence, 0, silence.size)
            runCatching { track.stop() }
            track.release()
        }.apply { isDaemon = true; start() }
    }

    private fun createChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "Zikr", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun startAsForeground() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun updateNotification() {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val openPi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val plusPi = PendingIntent.getBroadcast(
            this, 1,
            Intent(this, ZikrReceiver::class.java).setAction(ZikrReceiver.ACTION_PLUS), flags
        )
        val stopPi = PendingIntent.getService(
            this, 2,
            Intent(this, FloatingService::class.java).setAction(ACTION_STOP), flags
        )
        val icon = Icon.createWithResource(this, R.drawable.ic_notif)
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Zikr: ${Ui.fmt(ZikrPrefs.progress(this))}")
            .setContentText((if (ZikrPrefs.totalMode(this)) "Umumiy maqsad: " else "Kunlik maqsad: ") + Ui.fmt(ZikrPrefs.goal(this)))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setContentIntent(openPi)
            .addAction(Notification.Action.Builder(icon, "+1", plusPi).build())
            .addAction(Notification.Action.Builder(icon, "To'xtatish", stopPi).build())
            .build()
    }
}
