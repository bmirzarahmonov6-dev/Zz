package uz.zikr.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class ZikrWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        updateAll(context)
    }

    companion object {
        fun updateAll(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, ZikrWidget::class.java))
            if (ids.isEmpty()) return
            val rv = RemoteViews(c.packageName, R.layout.widget_zikr)
            rv.setTextViewText(R.id.widget_count, ZikrPrefs.progress(c).toString())
            rv.setTextViewText(R.id.widget_today, if (ZikrPrefs.totalMode(c)) "Jami" else "Bugun")
            val pi = PendingIntent.getBroadcast(
                c, 0,
                Intent(c, ZikrReceiver::class.java).setAction(ZikrReceiver.ACTION_PLUS),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.widget_root, pi)
            m.updateAppWidget(ids, rv)
        }
    }
}
