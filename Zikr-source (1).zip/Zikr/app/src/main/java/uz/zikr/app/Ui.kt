package uz.zikr.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import android.widget.Toast
import java.util.Locale
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

object Ui {
    val BG = 0xFF0B1220.toInt()
    val CARD = 0xFF1B2638.toInt()
    val TEXT = Color.WHITE
    val MUTED = 0xFF94A3B8.toInt()
    val ACCENT = 0xFF0B7A66.toInt()
    val ACCENT_LIGHT = 0xFF2DD4A8.toInt()
    val DANGER = 0xFF7F1D1D.toInt()
    val NEUTRAL = 0xFF334155.toInt()

    fun fmt(n: Int): String = String.format(Locale.US, "%,d", n).replace(',', ' ')

    fun goalDialog(a: Activity, onDone: () -> Unit) {
        val box = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(a, 24), dp(a, 12), dp(a, 24), 0)
        }
        val input = EditText(a).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "Masalan: 100000"
            setText(ZikrPrefs.goal(a).toString())
            setSelection(text.length)
        }
        val sw = Switch(a).apply {
            text = "Umumiy maqsad (hamma kunlar yig'indisi)"
            isChecked = ZikrPrefs.totalMode(a)
        }
        box.addView(input)
        box.addView(sw, wrapLp(a, 16))
        AlertDialog.Builder(a)
            .setTitle("Maqsadni yozing")
            .setView(box)
            .setPositiveButton("Saqlash") { _, _ ->
                val v = input.text.toString().filter { it.isDigit() }.take(9).toLongOrNull() ?: 0L
                if (v >= 1) {
                    ZikrPrefs.setGoal(a, v.toInt())
                    ZikrPrefs.setTotalMode(a, sw.isChecked)
                    onDone()
                } else {
                    Toast.makeText(a, "Son yozing", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Bekor", null)
            .show()
    }

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    fun page(c: Context): Pair<ScrollView, LinearLayout> {
        val root = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(c, 20), dp(c, 28), dp(c, 20), dp(c, 32))
        }
        val sv = ScrollView(c).apply {
            setBackgroundColor(BG)
            isFillViewport = true
            addView(root)
        }
        (c as? Activity)?.window?.statusBarColor = BG
        return sv to root
    }

    fun rounded(c: Context, color: Int, radiusDp: Int = 14): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(c, radiusDp).toFloat()
        }

    fun text(c: Context, s: String, size: Float = 16f, color: Int = TEXT, bold: Boolean = false): TextView =
        TextView(c).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    fun button(c: Context, label: String, color: Int = ACCENT, onClick: () -> Unit): Button =
        Button(c).apply {
            text = label
            isAllCaps = false
            textSize = 16f
            setTextColor(Color.WHITE)
            stateListAnimator = null
            background = rounded(c, color)
            setOnClickListener { onClick() }
        }

    fun lp(c: Context, heightDp: Int = 52, topDp: Int = 10): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(c, heightDp)).apply {
            topMargin = dp(c, topDp)
        }

    fun wrapLp(c: Context, topDp: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(c, topDp) }

    fun row(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    fun weightLp(c: Context, heightDp: Int = 48, gapDp: Int = 4): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(0, dp(c, heightDp), 1f).apply {
            marginStart = dp(c, gapDp)
            marginEnd = dp(c, gapDp)
        }

    fun card(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(c, CARD, 16)
        setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14))
    }

    fun gap(c: Context, h: Int): View = View(c).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(c, h))
    }
}
