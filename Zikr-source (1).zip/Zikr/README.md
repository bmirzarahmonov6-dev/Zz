# Zikr

Boshqa ilovalar ustida suzib turadigan oddiy zikr hisoblagich.

- Oddiy yashil doira, ichida faqat son
- Doirani bosish: +1
- Doirani sudrash: joyini o'zgartirish
- Doirani bosib turish: hech narsa qilmaydi (ilovaga otib ketmaydi)
- Ovoz tugmasi bilan sanash (yuqori +1, past -1), ekran o'chiq bo'lganda ham
- Kunlik maqsad, ketma-ket kunlar, 7/30 kunlik statistika
- Vidjet va bildirishnomada +1 tugmasi

## APK yig'ish (GitHub)

1. Bu fayllarni GitHub'dagi yangi repozitoriyga yuklang.
2. **Actions** bo'limiga kiring, **Build APK** ishga tushadi (yoki "Run workflow").
3. Tugagach, **Artifacts > zikr-apk** dan `app-debug.apk` ni yuklab oling.

## Ovoz tugmasi bilan sanashni yoqish

1. Ilova > Sozlamalar > "Ovoz tugmasi bilan sanash" ni yoqing.
2. "Maxsus imkoniyatlarni ochish" > Zikr > yoqing (bir marta).
