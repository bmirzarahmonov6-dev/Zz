package uz.zikr.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.min

class FloatingService : Service() {

    companion object {
        const val ACTION_STOP = "uz.zikr.app.STOP"
        const val CHANNEL_ID = "zikr_channel"
        const val NOTIF_ID = 1
    }

    private lateinit var wm: WindowManager
    private var view: CounterView? = null
    private lateinit var lp: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        handler.post { onPrefChanged(key) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createChannel()
        ZikrPrefs.sp(this).registerOnSharedPreferenceChangeListener(prefsListener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            ZikrPrefs.setRunning(this, false)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (view == null) {
            if (!Settings.canDrawOverlays(this)) {
                ZikrPrefs.setRunning(this, false)
                stopSelf()
                return START_NOT_STICKY
            }
            addOverlay()
        }
        ZikrPrefs.setRunning(this, true)
        return START_STICKY
    }

    override fun onDestroy() {
        ZikrPrefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefsListener)
        handler.removeCallbacksAndMessages(null)
        view?.let { runCatching { wm.removeView(it) } }
        view = null
        ZikrPrefs.setRunning(this, false)
        super.onDestroy()
    }

    private fun px(dp: Int): Int = (dp * resources.displayMetrics.density).toInt()

    private fun addOverlay() {
        val size = px(ZikrPrefs.sizeDp(this))
        val dm = resources.displayMetrics
        lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            val sx = ZikrPrefs.sp(this@FloatingService).getInt(ZikrPrefs.KEY_X, -1)
            val sy = ZikrPrefs.sp(this@FloatingService).getInt(ZikrPrefs.KEY_Y, -1)
            x = if (sx >= 0) sx else dm.widthPixels - size - px(12)
            y = if (sy >= 0) sy else dm.heightPixels / 3
        }
        clamp()
        val v = CounterView()
        view = v
        wm.addView(v, lp)
    }

    private fun clamp() {
        val dm = resources.displayMetrics
        lp.x = lp.x.coerceIn(0, (dm.widthPixels - lp.width).coerceAtLeast(0))
        lp.y = lp.y.coerceIn(0, (dm.heightPixels - lp.height).coerceAtLeast(0))
    }

    private fun onPrefChanged(key: String?) {
        val v = view ?: return
        if (key == ZikrPrefs.KEY_SIZE) {
            val s = px(ZikrPrefs.sizeDp(this))
            lp.width = s
            lp.height = s
            clamp()
            runCatching { wm.updateViewLayout(v, lp) }
        }
        v.invalidate()
        if (key == null || key.startsWith("d_") || key == ZikrPrefs.KEY_GOAL) updateNotification()
    }

    /** Doira: bitta oddiy yashil yumaloq va ichida son. Bosish = +1. Sudrash = ko'chirish. */
    private inner class CounterView : View(this@FloatingService) {
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        private val slop = ViewConfiguration.get(this@FloatingService).scaledTouchSlop
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        private var moved = false

        override fun onDraw(canvas: Canvas) {
            val ctx = this@FloatingService
            val r = min(width, height) / 2f
            bg.color = ZikrPrefs.palettes[ZikrPrefs.colorIdx(ctx)].color
            bg.alpha = ZikrPrefs.alphaPct(ctx) * 255 / 100
            canvas.drawCircle(width / 2f, height / 2f, r, bg)
            val s = ZikrPrefs.today(ctx).toString()
            val factor = when (s.length) {
                1, 2, 3 -> 0.42f
                4 -> 0.34f
                else -> 0.28f
            }
            tp.textSize = width * factor
            val y = height / 2f - (tp.descent() + tp.ascent()) / 2f
            canvas.drawText(s, width / 2f, y, tp)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && (abs(dx) > slop || abs(dy) > slop)) moved = true
                    if (moved) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        clamp()
                        runCatching { wm.updateViewLayout(this, lp) }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        ZikrPrefs.sp(this@FloatingService).edit()
                            .putInt(ZikrPrefs.KEY_X, lp.x)
                            .putInt(ZikrPrefs.KEY_Y, lp.y)
                            .apply()
                    } else {
                        ZikrPrefs.add(this@FloatingService, 1)
                    }
                }
            }
            return true
        }
    }

    private fun createChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "Zikr", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun startAsForeground() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun updateNotification() {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val openPi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val plusPi = PendingIntent.getBroadcast(
            this, 1,
            Intent(this, ZikrReceiver::class.java).setAction(ZikrReceiver.ACTION_PLUS), flags
        )
        val stopPi = PendingIntent.getService(
            this, 2,
            Intent(this, FloatingService::class.java).setAction(ACTION_STOP), flags
        )
        val icon = Icon.createWithResource(this, R.drawable.ic_notif)
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Zikr: ${ZikrPrefs.today(this)}")
            .setContentText("Kunlik maqsad: ${ZikrPrefs.goal(this)}")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setContentIntent(openPi)
            .addAction(Notification.Action.Builder(icon, "+1", plusPi).build())
            .addAction(Notification.Action.Builder(icon, "To'xtatish", stopPi).build())
            .build()
    }
}
