package uz.zikr.app

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class SettingsActivity : Activity() {

    private lateinit var accessText: TextView
    private val swatches = mutableListOf<View>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val (sv, root) = Ui.page(this)

        root.addView(Ui.text(this, "Sozlamalar", 26f, Ui.TEXT, true))

        // O'lcham
        val sizeLabel = Ui.text(this, "", 14f, Ui.MUTED)
        fun updSize() { sizeLabel.text = "Doira o'lchami: ${ZikrPrefs.sizeDp(this)} dp" }
        updSize()
        root.addView(sizeLabel, Ui.wrapLp(this, 24))
        root.addView(
            seek(ZikrPrefs.MAX_SIZE - ZikrPrefs.MIN_SIZE, ZikrPrefs.sizeDp(this) - ZikrPrefs.MIN_SIZE) { p ->
                ZikrPrefs.setSizeDp(this, p + ZikrPrefs.MIN_SIZE)
                updSize()
            }, Ui.wrapLp(this, 4)
        )

        // Shaffoflik
        val alphaLabel = Ui.text(this, "", 14f, Ui.MUTED)
        fun updAlpha() { alphaLabel.text = "Shaffoflik: ${ZikrPrefs.alphaPct(this)}%" }
        updAlpha()
        root.addView(alphaLabel, Ui.wrapLp(this, 20))
        root.addView(
            seek(70, ZikrPrefs.alphaPct(this) - 30) { p ->
                ZikrPrefs.setAlphaPct(this, p + 30)
                updAlpha()
            }, Ui.wrapLp(this, 4)
        )

        // Rang
        root.addView(Ui.text(this, "Doira rangi", 14f, Ui.MUTED), Ui.wrapLp(this, 20))
        val colorRow = Ui.row(this)
        ZikrPrefs.palettes.forEachIndexed { i, _ ->
            val v = View(this)
            v.setOnClickListener {
                ZikrPrefs.setColorIdx(this, i)
                refreshSwatches()
            }
            val lp = LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 40)).apply {
                marginEnd = Ui.dp(this@SettingsActivity, 10)
            }
            swatches.add(v)
            colorRow.addView(v, lp)
        }
        root.addView(colorRow, Ui.wrapLp(this, 8))
        refreshSwatches()

        // Maqsad
        root.addView(Ui.text(this, "Kunlik maqsad", 14f, Ui.MUTED), Ui.wrapLp(this, 24))
        val goalRow = Ui.row(this)
        for (g in listOf(33, 99, 100, 500, 1000)) {
            goalRow.addView(Ui.button(this, g.toString(), Ui.CARD) { ZikrPrefs.setGoal(this, g) }, Ui.weightLp(this, 44, 3))
        }
        root.addView(goalRow, Ui.wrapLp(this, 6))

        // Ovoz tugmasi
        val card = Ui.card(this)
        val sw = Switch(this).apply {
            text = "Ovoz tugmasi bilan sanash"
            setTextColor(Ui.TEXT)
            textSize = 16f
            isChecked = ZikrPrefs.volumeKeys(this@SettingsActivity)
            setOnCheckedChangeListener { _, on -> ZikrPrefs.setVolumeKeys(this@SettingsActivity, on) }
        }
        card.addView(sw)
        card.addView(
            Ui.text(this, "Yuqori tugma: +1\nPast tugma: -1\nYoqilganda ovoz balandligi tugmalari ishlamaydi.", 13f, Ui.MUTED),
            Ui.wrapLp(this, 8)
        )
        accessText = Ui.text(this, "", 13f, Ui.MUTED)
        card.addView(accessText, Ui.wrapLp(this, 10))
        card.addView(Ui.button(this, "Maxsus imkoniyatlarni ochish", Ui.ACCENT) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, Ui.lp(this, 48, 10))
        root.addView(card, Ui.wrapLp(this, 28))

        root.addView(Ui.button(this, "Orqaga", Ui.NEUTRAL) { finish() }, Ui.lp(this, 48, 24))

        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        accessText.text = if (accessEnabled())
            "Maxsus imkoniyat yoqilgan. Tugmalar ishlaydi."
        else
            "Maxsus imkoniyat o'chiq. Ochib, \"Zikr\" ni yoqing (bir marta kerak)."
        accessText.setTextColor(if (accessEnabled()) Ui.ACCENT_LIGHT else 0xFFFBBF24.toInt())
    }

    private fun accessEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val full = "$packageName/${VolumeKeyService::class.java.name}"
        val short = "$packageName/.VolumeKeyService"
        return s.contains(full) || s.contains(short)
    }

    private fun refreshSwatches() {
        val sel = ZikrPrefs.colorIdx(this)
        swatches.forEachIndexed { i, v ->
            v.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(ZikrPrefs.palettes[i].color)
                if (i == sel) setStroke(Ui.dp(this@SettingsActivity, 3), Color.WHITE)
            }
        }
    }

    private fun seek(max: Int, value: Int, onChange: (Int) -> Unit): SeekBar =
        SeekBar(this).apply {
            this.max = max
            progress = value
            progressTintList = ColorStateList.valueOf(Ui.ACCENT_LIGHT)
            thumbTintList = ColorStateList.valueOf(Ui.ACCENT_LIGHT)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) onChange(p)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
}
