package uz.zikr.app

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import java.util.Calendar
import java.util.Locale

data class ZikrPalette(val name: String, val color: Int)

object ZikrPrefs {
    const val FILE = "ZikrPrefs"
    const val KEY_GOAL = "daily_goal"
    const val KEY_COLOR = "color_idx"
    const val KEY_SIZE = "size_dp"
    const val KEY_ALPHA = "alpha_pct"
    const val KEY_VOLUME = "volume_keys"
    const val KEY_RUNNING = "running"
    const val KEY_X = "pos_x"
    const val KEY_Y = "pos_y"

    const val DEFAULT_GOAL = 100
    const val DEFAULT_SIZE = 72
    const val MIN_SIZE = 44
    const val MAX_SIZE = 140

    val palettes = listOf(
        ZikrPalette("Yashil", 0xFF0B7A66.toInt()),
        ZikrPalette("Ko'k", 0xFF1D4ED8.toInt()),
        ZikrPalette("Binafsha", 0xFF6D28D9.toInt()),
        ZikrPalette("Pushti", 0xFFBE185D.toInt()),
        ZikrPalette("Oltin", 0xFFB45309.toInt()),
        ZikrPalette("Kulrang", 0xFF334155.toInt())
    )

    fun sp(c: Context): SharedPreferences = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun dayKey(cal: Calendar = Calendar.getInstance()): String =
        String.format(
            Locale.US, "d_%04d%02d%02d",
            cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH)
        )

    fun today(c: Context): Int = sp(c).getInt(dayKey(), 0)

    fun goal(c: Context): Int = sp(c).getInt(KEY_GOAL, DEFAULT_GOAL).coerceAtLeast(1)
    fun setGoal(c: Context, v: Int) = sp(c).edit().putInt(KEY_GOAL, v.coerceAtLeast(1)).apply()

    fun colorIdx(c: Context): Int = sp(c).getInt(KEY_COLOR, 0).coerceIn(0, palettes.size - 1)
    fun setColorIdx(c: Context, v: Int) = sp(c).edit().putInt(KEY_COLOR, v).apply()

    fun sizeDp(c: Context): Int = sp(c).getInt(KEY_SIZE, DEFAULT_SIZE).coerceIn(MIN_SIZE, MAX_SIZE)
    fun setSizeDp(c: Context, v: Int) = sp(c).edit().putInt(KEY_SIZE, v).apply()

    fun alphaPct(c: Context): Int = sp(c).getInt(KEY_ALPHA, 100).coerceIn(30, 100)
    fun setAlphaPct(c: Context, v: Int) = sp(c).edit().putInt(KEY_ALPHA, v).apply()

    fun volumeKeys(c: Context): Boolean = sp(c).getBoolean(KEY_VOLUME, false)
    fun setVolumeKeys(c: Context, v: Boolean) = sp(c).edit().putBoolean(KEY_VOLUME, v).apply()

    fun running(c: Context): Boolean = sp(c).getBoolean(KEY_RUNNING, false)
    fun setRunning(c: Context, v: Boolean) = sp(c).edit().putBoolean(KEY_RUNNING, v).apply()

    fun resetToday(c: Context) {
        sp(c).edit().putInt(dayKey(), 0).apply()
        ZikrWidget.updateAll(c)
    }

    fun add(c: Context, delta: Int): Int {
        val key = dayKey()
        val old = sp(c).getInt(key, 0)
        val new = (old + delta).coerceAtLeast(0)
        if (new == old) return new
        sp(c).edit().putInt(key, new).apply()
        if (delta > 0) {
            val g = goal(c)
            if (old < g && new >= g) Haptics.long(c) else Haptics.tick(c)
        }
        ZikrWidget.updateAll(c)
        return new
    }

    fun total(c: Context): Int =
        sp(c).all.entries.filter { it.key.startsWith("d_") }.sumOf { (it.value as? Int) ?: 0 }

    fun streak(c: Context): Int {
        val g = goal(c)
        val cal = Calendar.getInstance()
        if (sp(c).getInt(dayKey(cal), 0) < g) cal.add(Calendar.DAY_OF_YEAR, -1)
        var n = 0
        while (sp(c).getInt(dayKey(cal), 0) >= g) {
            n++
            cal.add(Calendar.DAY_OF_YEAR, -1)
        }
        return n
    }

    fun lastDays(c: Context, days: Int): Pair<IntArray, Array<String>> {
        val values = IntArray(days)
        val labels = Array(days) { "" }
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -(days - 1))
        for (i in 0 until days) {
            values[i] = sp(c).getInt(dayKey(cal), 0)
            labels[i] = cal.get(Calendar.DAY_OF_MONTH).toString()
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return values to labels
    }
}

object Haptics {
    @Suppress("DEPRECATION")
    private fun vib(c: Context): Vibrator? =
        if (Build.VERSION.SDK_INT >= 31)
            c.getSystemService(VibratorManager::class.java)?.defaultVibrator
        else c.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator

    fun tick(c: Context) {
        vib(c)?.vibrate(VibrationEffect.createOneShot(18, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    fun long(c: Context) {
        vib(c)?.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE))
    }
}
