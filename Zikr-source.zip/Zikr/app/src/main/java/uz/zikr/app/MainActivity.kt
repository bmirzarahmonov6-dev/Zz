package uz.zikr.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.min

class MainActivity : Activity() {

    private lateinit var countText: TextView
    private lateinit var goalText: TextView
    private lateinit var progress: ProgressBar
    private lateinit var statusText: TextView
    private lateinit var toggleBtn: Button

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        runOnUiThread { refresh() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        ZikrPrefs.sp(this).registerOnSharedPreferenceChangeListener(listener)
        refresh()
    }

    override fun onPause() {
        ZikrPrefs.sp(this).unregisterOnSharedPreferenceChangeListener(listener)
        super.onPause()
    }

    private fun buildUi() {
        val (sv, root) = Ui.page(this)

        root.addView(Ui.text(this, "Zikr", 28f, Ui.TEXT, true))

        countText = Ui.text(this, "0", 72f, Ui.ACCENT_LIGHT, true).apply { gravity = Gravity.CENTER }
        root.addView(countText, Ui.wrapLp(this, 16))

        goalText = Ui.text(this, "", 15f, Ui.MUTED).apply { gravity = Gravity.CENTER }
        root.addView(goalText, Ui.wrapLp(this, 0))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(Ui.ACCENT_LIGHT)
            progressBackgroundTintList = ColorStateList.valueOf(Ui.CARD)
        }
        root.addView(progress, Ui.wrapLp(this, 12))

        val counterRow = Ui.row(this)
        counterRow.addView(Ui.button(this, "-1", Ui.NEUTRAL) { ZikrPrefs.add(this, -1) }, Ui.weightLp(this, 64).apply { weight = 1f })
        counterRow.addView(Ui.button(this, "+1") { ZikrPrefs.add(this, 1) }, Ui.weightLp(this, 64).apply { weight = 2f })
        root.addView(counterRow, Ui.wrapLp(this, 16))

        root.addView(Ui.text(this, "Kunlik maqsad", 14f, Ui.MUTED), Ui.wrapLp(this, 20))
        val targets = Ui.row(this)
        for (g in listOf(33, 99, 100, 500, 1000)) {
            targets.addView(Ui.button(this, g.toString(), Ui.CARD) { ZikrPrefs.setGoal(this, g) }, Ui.weightLp(this, 44, 3))
        }
        root.addView(targets, Ui.wrapLp(this, 6))

        toggleBtn = Ui.button(this, "Doirani yoqish") { toggleOverlay() }
        root.addView(toggleBtn, Ui.lp(this, 56, 24))

        statusText = Ui.text(this, "", 13f, Ui.MUTED).apply { gravity = Gravity.CENTER }
        root.addView(statusText, Ui.wrapLp(this, 8))

        val nav = Ui.row(this)
        nav.addView(Ui.button(this, "Statistika", Ui.CARD) {
            startActivity(Intent(this, StatsActivity::class.java))
        }, Ui.weightLp(this, 52, 4))
        nav.addView(Ui.button(this, "Sozlamalar", Ui.CARD) {
            startActivity(Intent(this, SettingsActivity::class.java))
        }, Ui.weightLp(this, 52, 4))
        root.addView(nav, Ui.wrapLp(this, 20))

        root.addView(Ui.button(this, "Nolga qaytarish", Ui.DANGER) {
            AlertDialog.Builder(this)
                .setMessage("Bugungi hisob nolga qaytarilsinmi?")
                .setPositiveButton("Ha") { _, _ -> ZikrPrefs.resetToday(this) }
                .setNegativeButton("Yo'q", null)
                .show()
        }, Ui.lp(this, 48, 16))

        setContentView(sv)
    }

    private fun refresh() {
        val t = ZikrPrefs.today(this)
        val g = ZikrPrefs.goal(this)
        countText.text = t.toString()
        goalText.text = "Kunlik maqsad: $g"
        progress.progress = min(100, t * 100 / g)
        val run = ZikrPrefs.running(this)
        toggleBtn.text = if (run) "Doirani o'chirish" else "Doirani yoqish"
        statusText.text = if (run) "Suzuvchi doira yoqilgan" else "Suzuvchi doira o'chiq"
    }

    private fun toggleOverlay() {
        if (ZikrPrefs.running(this)) {
            stopService(Intent(this, FloatingService::class.java))
            ZikrPrefs.setRunning(this, false)
        } else {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(
                    this, "Ruxsatni yoqing, keyin qaytib \"Doirani yoqish\"ni bosing", Toast.LENGTH_LONG
                ).show()
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
                return
            }
            startForegroundService(Intent(this, FloatingService::class.java))
            ZikrPrefs.setRunning(this, true)
        }
        refresh()
    }
}
